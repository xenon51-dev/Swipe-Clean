package com.swipeclean.app.worker

import android.content.Context
import androidx.work.*
import java.io.File
import java.util.concurrent.TimeUnit

class TrashExpiryWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        const val RETENTION_DAYS = 15L
        val RETENTION_MS = TimeUnit.DAYS.toMillis(RETENTION_DAYS)

        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiresBatteryNotLow(true)
                .build()

            val workRequest = PeriodicWorkRequestBuilder<TrashExpiryWorker>(6, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "SwipeClean15DayExpiryWorker",
                ExistingPeriodicWorkPolicy.KEEP,
                workRequest
            )
        }
    }

    override suspend fun doWork(): Result {
        val vaultDir = File(applicationContext.getExternalFilesDir(null), ".swipeclean_vault")
        if (!vaultDir.exists()) return Result.success()

        val now = System.currentTimeMillis()
        vaultDir.listFiles()?.forEach { stagedFile ->
            val ageMs = now - stagedFile.lastModified()
            if (ageMs >= RETENTION_MS) {
                stagedFile.delete()
            }
        }
        return Result.success()
    }
}
