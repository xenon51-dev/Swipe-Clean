package com.swipeclean.app.data

import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Environment
import java.io.File
import java.util.concurrent.TimeUnit

class FileScannerRepository(private val context: Context) {

    private val pendingExtensions = setOf(
        "crdownload", "part", "tmp", "download", "partial", "bak"
    )

    fun scanPendingAndIncompleteDownloads(): List<File> {
        val root = Environment.getExternalStorageDirectory()
        return root.walkTopDown()
            .maxDepth(4)
            .filter { file ->
                file.isFile && (
                    pendingExtensions.contains(file.extension.lowercase()) ||
                    file.name.endsWith(".crypt15.tmp") ||
                    (file.extension.lowercase() == "apk" && file.parent?.contains("Download") == true)
                )
            }
            .toList()
    }

    fun moveFileTo15DayVault(file: File): CleanableFileItem {
        val vaultDir = File(context.getExternalFilesDir(null), ".swipeclean_vault")
        if (!vaultDir.exists()) vaultDir.mkdirs()

        val targetFile = File(vaultDir, "${System.currentTimeMillis()}_${file.name}")
        file.renameTo(targetFile)

        val now = System.currentTimeMillis()
        val fifteenDaysMs = TimeUnit.DAYS.toMillis(15)

        return CleanableFileItem(
            id = targetFile.name,
            name = file.name,
            originalPath = file.absolutePath,
            vaultPath = targetFile.absolutePath,
            category = FileCategory.PENDING_JUNK,
            sizeBytes = targetFile.length(),
            smartReason = "Staged in 15-Day Recycle Vault",
            trashedAtEpochMs = now,
            expiresAtEpochMs = now + fifteenDaysMs
        )
    }

    fun restoreFromVault(item: CleanableFileItem): Boolean {
        val staged = File(item.vaultPath)
        val original = File(item.originalPath)
        original.parentFile?.mkdirs()
        return staged.renameTo(original)
    }

    fun queryUnusedApps(daysIdle: Int = 90): List<String> {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val cutoff = now - TimeUnit.DAYS.toMillis(daysIdle.toLong())
        return usm.queryUsageStats(UsageStatsManager.INTERVAL_YEARLY, cutoff, now)
            .filter { it.lastTimeUsed in 1 until cutoff }
            .map { it.packageName }
    }
}
