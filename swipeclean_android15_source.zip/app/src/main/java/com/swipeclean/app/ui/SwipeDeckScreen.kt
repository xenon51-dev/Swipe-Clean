package com.swipeclean.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.swipeclean.app.data.CleanableFileItem
import kotlinx.coroutines.launch

@Composable
fun SwipeDeckScreen(
    queue: List<CleanableFileItem>,
    onSwipeLeftTrash: (CleanableFileItem) -> Unit,
    onSwipeRightKeep: (CleanableFileItem) -> Unit,
    onInspectPreview: (CleanableFileItem) -> Unit
) {
    val currentItem = queue.firstOrNull() ?: return
    val scope = rememberCoroutineScope()
    val offsetX = remember(currentItem.id) { Animatable(0f) }
    val thresholdPx = 300f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .graphicsLayer {
                translationX = offsetX.value
                rotationZ = (offsetX.value / 25f).coerceIn(-16f, 16f)
            }
            .pointerInput(currentItem.id) {
                detectDragGestures(
                    onDragEnd = {
                        scope.launch {
                            when {
                                offsetX.value < -thresholdPx -> {
                                    offsetX.animateTo(-1200f, tween(220))
                                    onSwipeLeftTrash(currentItem)
                                }
                                offsetX.value > thresholdPx -> {
                                    offsetX.animateTo(1200f, tween(220))
                                    onSwipeRightKeep(currentItem)
                                }
                                else -> offsetX.animateTo(0f, tween(180))
                            }
                        }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        scope.launch {
                            offsetX.snapTo(offsetX.value + dragAmount.x)
                        }
                    }
                )
            }
    ) {
        Card(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(text = currentItem.category.name, style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = currentItem.name, style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = currentItem.smartReason, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.weight(1f))
                Button(onClick = { onInspectPreview(currentItem) }) {
                    Text("Preview File Before Moving to 15-Day Bin")
                }
            }
        }
    }
}
