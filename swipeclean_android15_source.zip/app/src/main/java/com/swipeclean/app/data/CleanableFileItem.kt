package com.swipeclean.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class FileCategory {
    PHOTO, VIDEO, APP, DOCUMENT, PENDING_JUNK
}

@Entity(tableName = "recycle_vault")
data class CleanableFileItem(
    @PrimaryKey val id: String,
    val name: String,
    val originalPath: String,
    val vaultPath: String,
    val category: FileCategory,
    val sizeBytes: Long,
    val smartReason: String,
    val isDuplicate: Boolean = false,
    val isLocked: Boolean = false,
    val trashedAtEpochMs: Long? = null,
    val expiresAtEpochMs: Long? = null
) {
    fun remainingDays(nowMs: Long = System.currentTimeMillis()): Double {
        val exp = expiresAtEpochMs ?: return 15.0
        return ((exp - nowMs).coerceAtLeast(0L)).toDouble() / (1000.0 * 60 * 60 * 24)
    }
}
