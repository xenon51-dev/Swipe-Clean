# SwipeClean — Android 15 (API 35) Tinder-Style File Cleaner

## Overview
SwipeClean is a native Android 14/15 (`targetSdk = 35`) storage cleaner built with **Kotlin**, **Jetpack Compose**, **Room**, and **WorkManager**.

### Key Features
1. **Tinder-Style Swipe Deck (`SwipeDeckScreen.kt`)**:
   - **Swipe Left**: Moves the previewed file into a designated **15-Day Recycle Vault** (`/.swipeclean_vault/` or `MediaStore.createTrashRequest` on Android 11+).
   - **Swipe Right**: Marks the file as safe/kept and excludes it from future cleanup scans.
   - **Swipe Up / Tap Eye**: Opens an interactive high-resolution file preview (EXIF sharpness analysis for burst photos, video playback preview, PDF/document snippet & SHA-256 duplicate verification, APK/cache split, and hex/progress inspection for incomplete `.crdownload`/`.part` files).
2. **All File Categories Supported (`FileScannerRepository.kt`)**:
   - **Photos & Screenshots**: Detects blurry burst shots (Laplacian variance) and expired OTP/tracking screenshots.
   - **Videos**: Identifies large 4K/60fps clips and Telegram/WhatsApp cached media.
   - **Apps & Cache**: Uses `UsageStatsManager` and `StorageStatsManager` to spot heavy games/apps unused for >90 days and trims uncommitted render/shader caches.
   - **Documents**: Finds duplicate PDFs, DOCX, and PPTX files via SHA-256 hashing.
   - **Undownloaded / Pending Junk**: Scans `/Download/` and app media directories for stalled `.crdownload`, `.part`, `.tmp`, orphaned `.apk` installers, and interrupted `.crypt15.tmp` backup shards.
3. **15-Day Auto-Expiring Recycle Vault (`TrashExpiryWorker.kt`)**:
   - Every left-swiped item is recorded in Room with `trashedAt` and `expiresAt = trashedAt + 15.days`.
   - A periodic `WorkManager` job runs every 6 hours to permanently purge items older than 15 days while allowing instant one-tap restore anytime before expiry.
